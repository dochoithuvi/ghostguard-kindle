return {
    name = "dcprointentgate",
    fullname = "DCPRO IntentShield 1.2.1 RC1",
    description = "Global action shield and independent reader shield by Dochoithuvi",
}
