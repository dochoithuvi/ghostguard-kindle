-- Presentation only: never inject events or change protection state.
local UI=require("ui/uimanager")
local Device=require("device")
local ButtonDialog=require("ui/widget/buttondialog")
local ImageWidget=require("ui/widget/imagewidget")
local root=debug.getinfo(1,"S").source:sub(2):match("(.*/)")
local Guide={}
local pages={
 {"Lật trang", "Vuốt ngang trái để sang trang tiếp; vuốt phải để quay lại (đọc trái sang phải)."},
 {"Aa và menu", "Vuốt dài từ mép dưới lên (ngoài 1/4 trái) để mở Aa, mục lục, bookmark và ghi chú nếu tab đã bật. Vuốt dọc dài giữa trang để mở menu."},
 {"Tra từ điển", "Vuốt chéo rồi nhấc tại từ. Lên trái: nửa trái. Lên phải: vùng đọc. Hai hướng xuống: 1/4 cuối trang. Cần sách văn bản và từ điển đã cài."},
 {"Chọn mục", "Vuốt ngang và nhấc tại mục/nút cần chọn. Vuốt dọc để cuộn danh sách. Không chạm đơn khi Shield bật."},
 {"Tắt bảo vệ", "Vào IntentShield > Dừng bảo vệ > Xác nhận. Không còn gesture thoát. Nút nguồn dừng phiên; Auto Resume có thể bật lại. Cứu hộ USB: DISABLE_INTENTGATE và DISABLE_INTENTSHIELD_BOOT."},
}
function Guide.show(index)
 local page=pages[index]; if not page then return end
 local screen=Device.screen
 local width=math.floor(screen:getWidth()*0.68)
 local height=math.floor(width*2/3)
 local pic=ImageWidget:new{file=root.."guide/"..index..".png",width=width,height=height,not_focusable=true}
 local dialog
 local function move(next_page)
  UI:close(dialog)
  if next_page then UI:nextTick(function() Guide.show(next_page) end) end
 end
 local row={}
 if index>1 then row[#row+1]={text="Trước",callback=function() move(index-1) end} end
 row[#row+1]={text="Đóng",callback=function() move(nil) end}
 if index<#pages then row[#row+1]={text="Tiếp",callback=function() move(index+1) end} end
 dialog=ButtonDialog:new{title="Gesture Guide "..index.."/"..#pages.." — "..page[1].."\n"..page[2],
    title_align="center",width_factor=0.94,dismissable=false,
    _added_widgets={pic},buttons={row}}
 UI:show(dialog)
end
return Guide
