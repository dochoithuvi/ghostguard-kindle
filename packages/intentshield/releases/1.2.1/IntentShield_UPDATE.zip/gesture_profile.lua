-- Reader gesture profile: receives only completed, accepted IntentShield strokes.
local P = {}
function P.action(v, w, h)
    if not v.compatible then return nil,"gate_rejected" end
    local dx,dy=math.abs(v.dx),math.abs(v.dy)
    local scale=w/1072
    if v.y0>=h*0.86 and v.x0>w*0.25 and v.x1>w*0.25 and v.dy<=-300*scale and dy>=3*dx then
        return 'PANEL'
    end
    -- Preserve Beta 3 gestures; add up-left for words in the left half.
    -- Down-left and down-right already work in the bottom quarter.
    -- Only completed strokes accepted by the original classifier are eligible.
    local up_right=v.dx>=90*scale and v.dy<=-90*scale
    local up_left=v.dx<=-90*scale and v.dy<=-90*scale and v.x1<=w*0.5
    local down_bottom=dx>=90*scale and v.dy>=90*scale and v.y1>=h*0.75
    if not (up_right or up_left or down_bottom) then return nil,"direction_or_region" end
    if dx/dy<0.65 or dx/dy>1.55 then return nil,"diagonal_ratio" end
    if v.net<140*scale or v.net>320*scale then return nil,"distance" end
    if v.duration<230000 then return nil,"duration" end
    if v.straight<0.88 then return nil,"straightness" end
    if v.y0>=h*0.86 or v.y1<=h*0.08 then return nil,"edge_region" end
    return 'DICT' 
end
function P.openPanel(reader, Event)
    -- ZenOS 4.3.x extends this native KOReader event with an initial tab.
    if reader.thumbnail and type(reader.thumbnail.onShowPageBrowser)=='function' then
        reader:handleEvent(Event:new('ShowPageBrowser','aa'))
        return true
    end
    if reader.menu and type(reader.menu.onShowReaderControls)=='function' then
        return reader.menu:onShowReaderControls()
    end
    return reader:handleEvent(Event:new('ShowConfigMenu'))
end
function P.lookup(reader, v, Geom)
    -- Initial beta: text-based reflowable books only; no touch/hold injection.
    if not reader.rolling or not reader.document or not reader.view or not reader.dictionary then return false,"unsupported_document" end
    if type(reader.document.getWordFromPosition)~='function' or type(reader.view.screenToPageTransform)~='function'
        or type(reader.dictionary.onLookupWord)~='function' then return false,"api_missing" end
    local transformed,pos=pcall(reader.view.screenToPageTransform,reader.view,Geom:new{x=v.x1,y=v.y1,w=0,h=0})
    if not transformed then return false,"transform_error" end
    if not pos then return false,"outside_page" end
    local ok,word=pcall(reader.document.getWordFromPosition,reader.document,pos,true)
    if not ok then return false,"word_api_error" end
    if type(word)~='table' or type(word.word)~='string' or not word.word:match('%S') then return false,"no_word" end
    -- CreDocument.sbox is already in screen coordinates on reflowable books.
    local boxes=word.sbox and {word.sbox} or nil
    local called,result=pcall(reader.dictionary.onLookupWord,reader.dictionary,word.word,false,boxes)
    if not called then return false,"dictionary_api_error" end
    if result~=true then return false,"dictionary_declined" end
    return true,"lookup_requested"
end
return P
