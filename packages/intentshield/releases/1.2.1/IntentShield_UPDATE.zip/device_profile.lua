-- Device allowlist and conservative Snow-to-Type-B adapter. No evdev injection.
local M={}
M.models={KindleBasic3={600,800},KindleBasic4={1072,1448},KindleBasic5={1072,1448},KindlePaperWhite4={1072,1448}}
function M.valid(device)
    local d=M.models[device.model]; local s=device.screen
    return d and s and s:getRotationMode()==0 and s:getWidth()==d[1] and s:getHeight()==d[2]
end
function M.newGate(Gate,device,fast)
    local d=assert(M.models[device.model]); local g=Gate.new(d[1],d[2],fast)
    if device.model~='KindleBasic3' or not device.input or not device.input.snow_protocol then return g end
    -- Snow uses tracking IDs as slots and BTN_TOUCH:0 as final release.
    -- Translate only observed contacts; never infer a start from coordinates.
    local A={core=g,ids={},nextslot=0,selected=nil,release=false,discard=false,normal=false,fast=g.fast,blocked=false}
    function A:resetSnow()
        self.core:reset(); self.ids={}; self.nextslot=0; self.selected=nil; self.release=false; self.discard=false
    end
    function A:feed(t,typ,code,val)
        if self.normal then local out=self.core:feed(t,typ,code,val); self.blocked=self.core.blocked; return out end
        if typ==0 and code==3 then self.blocked=true; return {} end
        if self.last and t<self.last then self.blocked=true; return {} end
        self.last=t
        if self.blocked then return {} end
        if typ==3 and code==57 and val==-1 then
            -- A newer sane panel: discard the ambiguous contact, switch for future frames.
            self:resetSnow(); self.normal=true; return {}
        end
        if typ==3 and code==47 then self.discard=true; return {} end
        if typ==1 and code==330 then
            if val==0 then self.release=true elseif val==1 and self.release then self.discard=true end
            return {}
        end
        if self.release and typ==3 and (code==53 or code==54 or code==57) then self.discard=true end
        if typ==3 and code==57 then
            if val<0 or val%1~=0 then self.discard=true; return {} end
            if self.ids[val]==nil then
                if self.nextslot>31 then self.discard=true; return {} end
                self.ids[val]=self.nextslot; self.nextslot=self.nextslot+1
                -- More than one tracking ID in one physical contact group is ambiguous.
                if self.nextslot>1 then self.discard=true end
                self.core:feed(t,3,47,self.ids[val]); self.core:feed(t,3,57,val)
            end
            self.selected=self.ids[val]; self.core:feed(t,3,47,self.selected)
        elseif typ==3 and (code==53 or code==54) then
            if self.selected~=nil then self.core:feed(t,typ,code,val) end
        elseif typ==0 and code==0 then
            if self.release then
                if self.discard then self:resetSnow(); return {} end
                for _,slot in pairs(self.ids) do self.core:feed(t,3,47,slot); self.core:feed(t,3,57,-1) end
                local out=self.core:feed(t,0,0,val); self.blocked=self.core.blocked
                self:resetSnow(); return out
            end
            self.core:feed(t,0,0,val)
        end
        self.blocked=self.core.blocked
        return {}
    end
    return A
end
function M.touchEvent(device,typ,code)
    return (typ==0 and (code==0 or code==3)) or (typ==3 and (code==47 or code==53 or code==54 or code==57))
        or (device.model=='KindleBasic3' and typ==1 and code==330)
end
return M
