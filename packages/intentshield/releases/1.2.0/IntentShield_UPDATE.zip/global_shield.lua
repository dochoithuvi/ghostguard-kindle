-- IntentShield 1.0 global action gate. No evdev injection/grab.
local UI = require('ui/uimanager')
local Device = require('device')
local Event = require('ui/event')
local Geom = require('ui/geometry')
local Time = require('ui/time')
local BD = require('ui/bidi')
local lfs = require('libs/libkoreader-lfs')
local root=debug.getinfo(1,'S').source:sub(2):match('(.*/)')
local Gate=dofile(root..'intent_gate.lua')
local Devices=dofile(root..'device_profile.lua')
local Profile=dofile(root..'gesture_profile.lua')
local License=dofile(root..'license_gate.lua')
local S={gen=0,active=false,license=License}
local DIS='/mnt/us/DISABLE_INTENTGATE'
local AUTO='/mnt/us/ENABLE_INTENTSHIELD_GLOBAL'
local REPORT='/mnt/us/GhostGuard_Reports/IntentGate'
local function exists(p) return lfs.attributes(p)~=nil end
-- KOReader input.lua calls eventAdjustHook before its inhibited touch handler.
local function inputInhibited()
    return Device.input and Device.input._abs_ev_handler~=nil
end
local function contactOpen(gate)
    if not gate then return false end
    if gate.ids and next(gate.ids) then return true end
    for _,s in pairs((gate.core or gate).slots or {}) do if s.c then return true end end
    return false
end
local function elapsedMs(start)
    if start and type(Time.to_ms)=='function' then return Time.to_ms(Time.now()-start) end
    return nil
end
local function screenOK()
    return Devices.valid(Device)
end
local function ts(e)
    local t=e.time
    if type(t)=='number' then return t>1e12 and math.floor(t) or math.floor(t*1e6) end
    if t then local a,b=tonumber(t.sec or t.tv_sec),tonumber(t.usec or t.tv_usec); if a and b then return a*1e6+b end end
end
function S:log(line)
    if self.file then local ok,v=pcall(self.file.write,self.file,line..'\n'); if not ok or not v then self.log_failed=true end end
end
-- Best effort diagnostic export, independent of protection state and fault handling.
function S:exportSummary(reason,path)
    if not path then return end
    local final=path:gsub('%.log$','_SUMMARY.txt')
    local temp=final..'.tmp'
    local f=io.open(temp,'w')
    if not f then return end
    local ok,w=pcall(f.write,f,table.concat({
        'IntentShield 1.2.0 Stable',
        'Model: '..tostring(Device.model),
        'End: '..os.date('%Y-%m-%d %H:%M:%S'),
        'Reason: '..tostring(reason),
        'Raw events: '..tostring(self.raw or 0),
        'Contacts: '..tostring(self.contacts or 0),
        'Blocked native gestures: '..tostring(self.blocked or 0),
        'Dispatched actions: '..tostring(self.actions or 0),
        'Auto Resume (session): '..tostring(self.auto_resume==true),
        'Log error: '..tostring(self.log_failed==true),
        'Counts do not measure ghost touch accuracy.', ''},'\n'))
    local closed,c=pcall(f.close,f)
    if ok and w and closed and c then
        if not os.rename(temp,final) then os.remove(temp) end
    else os.remove(temp) end
end
-- Native gesture isolation is deliberately restricted to the tested Basic 2022 family.
-- The raw event hook and the original UI gate remain the only source of allowed actions.
function S:isolateNative()
    if Device.model~='KindleBasic4' then return end
    local input=Device.input; local gd=input and input.gesture_detector
    if not gd or type(gd.feedEvent)~='function' or type(gd.dropContacts)~='function' or type(input.clearTimeouts)~='function' then
        self:log('NATIVE,unsupported_api'); return
    end
    local ok=pcall(function() gd:dropContacts(); input:clearTimeouts() end)
    if not ok then self:log('NATIVE,cleanup_refused'); return end
    local original=gd.feedEvent; local owner=self
    local wrapper=function(detector,frames,...)
        if owner.active then owner.native_frames=(owner.native_frames or 0)+1; return {} end
        return original(detector,frames,...)
    end
    self.native_detector=gd; self.native_original=original; self.native_wrapper=wrapper
    gd.feedEvent=wrapper; self:log('NATIVE,isolated')
end
function S:restoreNative()
    local gd=self.native_detector
    if gd and gd.feedEvent==self.native_wrapper then
        pcall(function() gd:dropContacts(); Device.input:clearTimeouts() end)
        gd.feedEvent=self.native_original
    end
    self.native_detector=nil; self.native_original=nil; self.native_wrapper=nil
end
function S:stop(reason,keep_resume)
    self.gen=self.gen+1; self.active=false; self.pending=nil; self.gate=nil; self.top=nil; self.exit=nil
    if not keep_resume then self.resume=false end
    if self.timer then UI:unschedule(self.timer); self.timer=nil end
    if self.monitor then UI:unschedule(self.monitor); self.monitor=nil end
    if self.wake then UI:unschedule(self.wake); self.wake=nil end
    if self.wrapper and UI.handleInputEvent==self.wrapper then UI.handleInputEvent=self.original end
    self.wrapper=nil; self.original=nil
    self:restoreNative()
    if self.file then self:log('END,'..tostring(reason)..',raw='..self.raw..',contacts='..self.contacts..',blocked_gestures='..self.blocked..',actions='..self.actions); pcall(self.file.flush,self.file); pcall(self.file.close,self.file); self.file=nil; pcall(self.exportSummary,self,reason,self.report_path); self.report_path=nil end
end
function S:context()
    local top=UI:getTopmostVisibleWidget()
    if not top then return nil,nil end
    local r=package.loaded['apps/reader/readerui']; r=r and r.instance
    -- Only the live reader or its exact registered dialog; never accept overlays.
    if r and r.document and (top==r or top==r.dialog) then return top,r end
    return top,nil
end
function S:dispatch(v,top,reader,kind)
    if not self.active then return end
    if inputInhibited() or self.inhibit_drain then self:log('SKIP,input_inhibited'); return end
    if self.pending then self:log('SKIP,pending_action'); return end
    if self.last and v.ts-self.last<500000 then self:log('SKIP,rate_limit'); return end
    local token={}; self.pending=token; local gen=self.gen; local queued=Time.now()
    UI:nextTick(function()
        if self.gen~=gen or self.pending~=token or not self.active then return end
        self.pending=nil
        local ok,err=pcall(function()
            local delay=elapsedMs(queued)
            if inputInhibited() or self.inhibit_drain then self:log('SKIP,input_inhibited_at_dispatch'); return end
            if delay and delay>1000 then self:log('SKIP,stale_action,queue_ms='..delay); return end
            if delay and delay>=100 then self:log('PERF,queue_ms='..delay..',kind='..kind) end
            local now,r=self:context()
            if exists(DIS) or not screenOK() or now~=top or r~=reader then self:log('SKIP,context_changed'); return end
            self.last=v.ts; self.actions=self.actions+1
            self:log('ACTION,'..kind..','..v.ts..','..tostring(v.x1)..','..tostring(v.y1))
            local begun=Time.now()
            if kind=='PAGE' then
                local d=BD.flipDirectionIfMirroredUILayout(v.dx<0 and 'west' or 'east')=='west' and 1 or -1
                if reader.view and reader.view.inverse_reading_order then d=-d end
                reader:handleEvent(Event:new('GotoViewRel',d))
            elseif kind=='MENU' then reader:handleEvent(Event:new('ShowMenu'))
            elseif kind=='PANEL' then
                Profile.openPanel(reader,Event)
            elseif kind=='DICT' then
                local ok,found,reason=pcall(Profile.lookup,reader,v,Geom)
                self:log('DICT_RESULT,'..(ok and tostring(reason) or 'lookup_exception'))
                if not ok or not found then self:log('SKIP,dictionary_not_opened') end
            elseif kind=='SELECT' then
                -- End of an intentional horizontal stroke, not a physical tap.
                UI:sendEvent(Event:new('Gesture',{ges='tap',pos=Geom:new{x=v.x1,y=v.y1,w=0,h=0},time=Time.now()}))
            elseif kind=='SCROLL' then
                UI:sendEvent(Event:new('Gesture',{ges='swipe',pos=Geom:new{x=v.x0,y=v.y0,w=0,h=0},end_pos=Geom:new{x=v.x1,y=v.y1,w=0,h=0},direction=v.dy<0 and 'north' or 'south',distance=math.abs(v.dy),time=Time.now()}))
            end
            local spent=elapsedMs(begun)
            if spent and spent>=100 then self:log('PERF,dispatch_ms='..spent..',kind='..kind) end
        end)
        if not ok then self:log('FAULT,dispatch,'..tostring(err):gsub('[\r\n]',' ')); self:stop('dispatch_fault') end
    end)
end
function S:rawEvent(e)
    if not self.active or self.exiting then return end
    if self.log_failed then self:stop('guard_stop'); return end
    local a,b,c=tonumber(e.type),tonumber(e.code),tonumber(e.value)
    if not Devices.touchEvent(Device,a,b) then return end
    local inhibited=inputInhibited()
    if inhibited then
        self.pending=nil
        if not self.inhibit_drain then self:log('INPUT,inhibited'); self.inhibit_drain=true end
    elseif self.inhibit_drain and not contactOpen(self.gate) then
        self.inhibit_drain=false; self:log('INPUT,restored_clean')
    end
    local top,r=self:context()
    -- Keep tracking across UI transitions, including when no visible widget exists.
    -- A contact spanning a transition cannot dispatch to the new widget.
    if top~=self.top then
        self.pending=nil; self.exit=nil; self.top=top
        if contactOpen(self.gate) then self.context_drain=true end
    end
    local t=ts(e); if not t or not c then self:stop('bad_raw'); return end
    self.raw=self.raw+1
    local had_contact=a==0 and b==0 and self.reject_run>=30 and contactOpen(self.gate)
    local out=self.gate:feed(t,a,b,c)
    if self.gate.blocked then
        self.pending=nil; self.exit=nil
        if not self.desync_logged then self:log('DESYNC,quarantined_until_new_session'); self.desync_logged=true end
        return
    end
    if a==0 and b==0 and had_contact and not contactOpen(self.gate) and self.reject_run>=30 and self.native_detector and self.native_detector.feedEvent==self.native_wrapper then
        -- Only native parser/timers; raw gate and slot state remain untouched.
        local clean=pcall(function() self.native_detector:dropContacts(); Device.input:clearTimeouts() end)
        self:log('RECOVERY,native_only,all_observed_contacts_released='..tostring(clean))
        self.reject_run=0
    end
    local context_drain=self.context_drain
    if a==0 and b==0 and not contactOpen(self.gate) then self.context_drain=false end
    if not top then return end
    local w,h=Device.screen:getWidth(),Device.screen:getHeight()
    local scale=w/1072
    for _,v in ipairs(out) do
        self.contacts=self.contacts+1
        if self.contacts<=5000 then self:log(string.format('CONTACT,%d,%s,%d,%d,%.1f,%.1f,%.3f,%.1f',v.ts,v.reason,v.duration,v.points,v.dx,v.dy,v.straight,v.maxstep)) end
        if not v.compatible then self.reject_run=(self.reject_run or 0)+1 else self.reject_run=0 end
        if not inhibited and not self.inhibit_drain and not context_drain and v.compatible and v.x0 and v.y0 and v.x1 and v.y1 then
            local horizontal=math.abs(v.dx)>=2*math.abs(v.dy)
            local vert=math.abs(v.dy)>=3*math.abs(v.dx)
            -- Former escape zone: keep long vertical strokes inert, never disable protection.
            if vert and math.abs(v.dy)>=350*scale and v.x0<=w/4 and v.x1<=w/4 then
                self:log('SKIP,former_escape_zone'); return
            end
            local action,why
            if r then action,why=Profile.action(v,w,h) else why='not_reader' end
            if math.abs(v.dx)>=90*scale and math.abs(v.dy)>=90*scale and not horizontal and not vert then
                self:log(string.format('PROFILE,%d,%s,x0=%d,y0=%d,x1=%d,y1=%d,net=%.1f,straight=%.3f',v.ts,action or why or 'none',v.x0,v.y0,v.x1,v.y1,v.net,v.straight))
            end
            if action then self:dispatch(v,top,r,action)
            elseif horizontal then self:dispatch(v,top,r,r and 'PAGE' or 'SELECT')
            elseif vert and r and math.abs(v.dy)>=300*scale then self:dispatch(v,top,r,'MENU')
            elseif vert and not r then self:dispatch(v,top,nil,'SCROLL') end
        end
    end
end
function S:start(seconds,auto_resume)
    if self.active then return true end
    if self.sync_pid then return false,'License sync in progress' end
    local licensed,why=License.check(true)
    if not licensed then return false,'License: '..tostring(why) end
    if exists(DIS) or not screenOK() then return false,'disabled or incompatible device' end
    if not Device.input or type(Device.input.registerEventAdjustHook)~='function' or type(UI.handleInputEvent)~='function' or type(UI.sendEvent)~='function' or type(Time.now)~='function' then return false,'incompatible KOReader APIs' end
    local old=Device.input._dcpro_intentgate_trial
    if old and old.owner then old.owner:stop('global_start') end
    lfs.mkdir('/mnt/us/GhostGuard_Reports'); lfs.mkdir(REPORT)
    local stem=REPORT..'/'..os.date('%Y%m%d_%H%M%S')
    local path=stem..'_GLOBAL.log'
    local n=0
    while exists(path) do n=n+1; path=stem..'_'..n..'_GLOBAL.log' end
    local f=io.open(path,'a'); if not f then return false,'log unavailable' end
    self.report_path=path
    self.inhibit_drain=false; self.context_drain=false; self.desync_logged=false; self.reject_run=0; self.native_frames=0; self.watchdog_last=0
    self.file=f; self.log_failed=false; self.gen=self.gen+1; self.active=true; self.manual_off=false; self.exiting=false; self.resume=false; self.auto_resume=auto_resume==true; self.seconds=seconds; self.raw=0; self.contacts=0; self.blocked=0; self.actions=0; self.last=nil; self.gate=Devices.newGate(Gate,Device,false); self.top=nil; self.pending=nil
    self:log('START,IntentShield1.2.0-stable,GLOBAL,model='..tostring(Device.model)..',duration='..tostring(seconds)..',auto_resume='..tostring(self.auto_resume))
    if not self.installed then
        Device.input:registerEventAdjustHook(function(_,ev)
            if S.active then local ok,err=pcall(S.rawEvent,S,ev); if not ok then S:log('FAULT,raw,'..tostring(err)); S:stop('raw_fault') end end
        end); self.installed=true
    end
    self.original=UI.handleInputEvent; local original=self.original
    self.wrapper=function(m,e)
        if S.active and type(e)=='table' and e.handler=='onGesture' then S.blocked=S.blocked+1; return end
        return original(m,e)
    end
    UI.handleInputEvent=self.wrapper
    self:isolateNative()
    local gen=self.gen
    self.monitor=function()
        if not self.active or gen~=self.gen then return end
        if exists(DIS) or not screenOK() or UI.handleInputEvent~=self.wrapper or self.log_failed then self:stop('monitor_stop'); self.manual_off=true; return end
        if not License.check(false) then self:stop('license_invalid'); self.manual_off=true; return end
        if self.native_detector and self.native_detector.feedEvent~=self.native_wrapper then
            self:log('NATIVE,hook_changed'); self.native_detector=nil; self.native_original=nil; self.native_wrapper=nil
        end
        local now=os.time()
        if (self.reject_run>=30 or self.desync_logged) and now-self.watchdog_last>=10 then
            self.watchdog_last=now
            self:log('WATCHDOG,rejected_run='..self.reject_run..',contact_open='..tostring(contactOpen(self.gate))..',desync='..tostring(self.desync_logged)..',native_frames='..self.native_frames)
        end
        if self.file then local started=Time.now(); local ok,v=pcall(self.file.flush,self.file); if not ok or not v then self:stop('flush_failed'); return end; local ms=elapsedMs(started); if ms and ms>=100 then self:log('PERF,flush_ms='..ms) end end
        UI:scheduleIn(2,self.monitor)
    end
    UI:scheduleIn(2,self.monitor)
    if seconds>0 then self.timer=function() if gen==self.gen then self:stop('timeout'); self.manual_off=true end end; UI:scheduleIn(seconds,self.timer) end
    return true
end
function S:suspend()
    self.suspended=true
    if self.active then self.resume=self.auto_resume and self.seconds==0; self:stop('suspend',true)
    elseif self.wake then self:stop('second_suspend') end
end
function S:onResume()
    self.suspended=false
    if self.auto_pending then self:requestAuto() end
    if self.resume and not self.wake then
        self.resume=false; local gen=self.gen
        self.wake=function() self.wake=nil; if self.gen==gen and not exists(DIS) then self:start(0,true) end end
        UI:scheduleIn(5,self.wake)
    end
end
-- Auto Activate: never infer a valid license from a successful download.
-- The existing signed registry and policy verifier remain authoritative.
local function autoLog(msg)
    msg=tostring(msg):gsub('[\r\n]',' '):sub(1,1500)
    local ok,f=pcall(io.open,REPORT..'/auto_license.log','a')
    if ok and f then
        pcall(function() f:write(os.date('%Y-%m-%d %H:%M:%S'),' ',msg,'\n'); f:close() end)
    end
end
function S:autoAllowed()
    return exists(AUTO) and not exists(DIS) and not self.manual_off and not self.suspended
        and not self.active and screenOK()
        and not exists(root..'../dcghostguardpro.koplugin')
        and not exists('/mnt/us/ENABLE_GHOSTGUARD_ZEN_BOOT')
end
function S:autoStartVerified()
    if not self:autoAllowed() or self.sync_pid then return false end
    local valid,why=License.check(true)
    if not valid then autoLog('LICENSE_REFUSED '..tostring(why)); return false end
    -- Non-Basic2022 beta devices: automatically protect only for a bounded trial.
    local beta=Device.model~='KindleBasic4'
    local ok,started,detail=pcall(self.start,self,beta and 60 or 0,not beta)
    if not ok then self:stop('autostart_fault'); self.manual_off=true; self.auto_pending=false; autoLog('START_ERROR '..tostring(started)); return false end
    self.auto_pending=false
    autoLog(started and (beta and 'GLOBAL_ON;DEVICE_BETA_60S;AUTO_RESUME_OFF' or 'GLOBAL_ON;AUTO_RESUME_ON') or ('START_REFUSED '..tostring(detail)))
    return started==true
end
function S:autoActivate()
    if not self.auto_pending or not self:autoAllowed() or self.sync_pid then return end
    if self:autoStartVerified() or not self.auto_pending then return end
    if (self.auto_attempts or 0)>=2 then autoLog('AUTO_SYNC_LIMIT; use License menu'); return end
    -- Do not turn on Wi-Fi or request a network dialog.
    local netok,net=pcall(require,'ui/network/manager')
    if not netok or type(net.isConnected)~='function' then autoLog('NETWORK_API_UNAVAILABLE; use License menu'); return end
    local cok,connected=pcall(net.isConnected,net)
    if not cok or not connected then autoLog('WAIT_WIFI'); return end
    local fok,util=pcall(require,'ffi/util')
    if not fok or type(util.runInSubProcess)~='function' or type(util.isSubProcessDone)~='function' then
        autoLog('ASYNC_API_UNAVAILABLE; use License menu'); return
    end
    self.auto_attempts=(self.auto_attempts or 0)+1
    autoLog('SYNC_START attempt='..self.auto_attempts)
    local ok,pid=pcall(util.runInSubProcess,function()
        local synced,detail,allowed,policy=License.sync()
        autoLog('SYNC_RESULT success='..tostring(synced)..' allowed='..tostring(allowed)..' '..tostring(detail)..' '..tostring(policy))
    end)
    if not ok or type(pid)~='number' or pid<=0 then autoLog('WORKER_START_FAILED '..tostring(pid)); return end
    self.sync_pid=pid
    local polls=0
    local function poll()
        if self.sync_pid~=pid then return end
        local checked,done=pcall(util.isSubProcessDone,pid)
        if not checked then
            autoLog('WORKER_POLL_ERROR; restart KOReader before manual sync')
            return -- keep the lock: never run concurrent cache writers
        end
        if not done then
            polls=polls+1
            if polls==75 then autoLog('SYNC_SLOW; reader remains usable') end
            UI:scheduleIn(1,poll)
            return
        end
        self.sync_pid=nil
        -- Recheck in parent after child has finished; never trust its exit status.
        if self.auto_pending and self:autoAllowed() then self:autoStartVerified() end
    end
    UI:scheduleIn(1,poll)
end
function S:requestAuto()
    if not self.auto_pending or not self:autoAllowed() or self.sync_pid or self.auto_scheduled then return end
    self.auto_scheduled=true
    UI:scheduleIn(2,function()
        self.auto_scheduled=false
        local ok,err=pcall(self.autoActivate,self)
        if not ok then autoLog('AUTO_SYNC_ERROR '..tostring(err)) end
    end)
end
function S:maybeAuto()
    if self.auto_checked then return end
    self.auto_checked=true
    self.auto_pending=self:autoAllowed()
    if self.auto_pending then self:requestAuto() end
end
return S
