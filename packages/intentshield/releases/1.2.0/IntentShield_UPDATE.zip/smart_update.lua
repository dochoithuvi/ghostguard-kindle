-- User-triggered update; no background polling of GitHub, no forced reboot.
local UI=require('ui/uimanager')
local Info=require('ui/widget/infomessage')
local Confirm=require('ui/widget/confirmbox')
local lfs=require('libs/libkoreader-lfs')
local M={busy=false}
local ROOT='/mnt/us/.dcpro_intentshield'
local TOOL=ROOT..'/tools/IntentShield_UPDATE.tool'
local RESULT=ROOT..'/update-state/result'
local function read(p) local f=io.open(p,'rb'); if not f then return nil end; local s=f:read('*a'); f:close(); return s end
local function notice(t) UI:show(Info:new{text=t,timeout=8}) end
local function kr()
    local r
    for _,p in ipairs({'/mnt/us/koreader','/mnt/us/extensions/koreader'}) do
        if lfs.attributes(p..'/plugins/dcprointentgate.koplugin/update-version.txt','mode')=='file' then if r then return nil end; r=p end
    end
    return r
end
local function run(mode,seq,callback)
    if M.busy then notice('Đang xử lý cập nhật.'); return end
    local p=kr(); local launcher=p and read(p..'/koreader.sh')
    if not launcher or not launcher:find('DCPRO_SMART_UPDATE_HOOK_V1',1,true) or not lfs.attributes(TOOL) then notice('Chưa có Smart Update hook tương thích. Dùng OneClick.'); return end
    local ok,util=pcall(require,'ffi/util')
    if not ok or type(util.runInSubProcess)~='function' or type(util.isSubProcessDone)~='function' then notice('KOReader không hỗ trợ cập nhật nền.'); return end
    local okn,net=pcall(require,'ui/network/manager')
    if not mode:match('_local$') and (not okn or not net:isConnected()) then notice('Hãy kết nối Wi-Fi trước.'); return end
    if seq and not tostring(seq):match('^%d+$') then return end
    -- Both command and path are constant/allowlisted; sequence is digits only.
    os.remove(RESULT)
    local command='/bin/sh '..TOOL..' '..mode..' '..p..(seq and (' '..seq) or '')
    local started,pid=pcall(util.runInSubProcess,function() os.execute(command) end)
    if not started or type(pid)~='number' or pid<=0 then notice('Không khởi chạy được updater.'); return end
    M.busy=true; notice(mode=='check' and 'Đang kiểm tra cập nhật…' or 'Đang tải và xác minh bản cập nhật…')
    local function poll()
        local checked,done=pcall(util.isSubProcessDone,pid)
        if not checked then notice('Không xác định được tiến trình cập nhật. Khởi động lại KOReader trước khi thử lại.'); return end
        if not done then UI:scheduleIn(1,poll); return end
        M.busy=false; callback((read(RESULT) or 'ERROR No updater result'):sub(1,512):gsub('[\r\n]+$',''))
    end
    UI:scheduleIn(1,poll)
end
local function restart()
    UI:show(Confirm:new{text='Gói đã xác minh. Khởi động lại KOReader để cài đặt? Không reboot Kindle.',ok_text='Restart KOReader',ok_callback=function()
        if type(UI.restartKOReader)=='function' then UI:restartKOReader() else notice('Thoát rồi mở lại KOReader để áp dụng.'); end
    end})
end
function M.check(offline)
    local suffix=offline==true and '_local' or ''
    run('check'..suffix,nil,function(s)
        local seq,ver=s:match('^AVAILABLE (%d+) ([%w%.%-]+)$')
        if seq then UI:show(Confirm:new{text='Có bản '..ver..'. Tải và xác minh?',ok_text='Update now',ok_callback=function()
            run('prepare'..suffix,seq,function(result) if result:match('^READY ') then restart() else notice(result) end end)
        end})
        elseif s:match('^CURRENT ') then notice('Đã ở phiên bản mới nhất.') else notice(s) end
    end)
end
function M.menu()
    return {text='Software Update — 1.2.0 Stable',sub_item_table={
        {text='Kiểm tra cập nhật / Update now',callback=function() M.check(false) end},
        {text='Trạng thái cập nhật',callback=function() notice(read(RESULT) or 'Chưa có cập nhật. Chỉ nhận bản phát hành đã ký.') end},
    }}
end
return M
