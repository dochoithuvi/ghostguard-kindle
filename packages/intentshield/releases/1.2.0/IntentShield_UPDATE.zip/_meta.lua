return {
    name = "dcprointentgate",
    fullname = "DCPRO IntentShield 1.2.0 Stable",
    description = "Global action shield and independent reader shield by Dochoithuvi",
}
